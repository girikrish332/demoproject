let CanvasMock = (function() {

    return {

    }
}());

export {CanvasMock};
